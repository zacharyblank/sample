# Load up the stdlib
. ${SCRIPTPACK_STDLIB_ROOT}/main.sh

# Our own functions
. ${SCRIPTPACK_PHP_ROOT}/composer.sh
. ${SCRIPTPACK_PHP_ROOT}/install.sh
. ${SCRIPTPACK_PHP_ROOT}/version.sh
